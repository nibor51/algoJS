const assert = require('assert')
const scripts = require('../index.js')

describe('BONUS', () => {
    describe('Exercice CXXIII', () => {
        it('Retourne le prix à payer en fonction de l\'heure d\'arrivé', () => {
            assert.equal(scripts.auberge(7), 45)
            assert.equal(scripts.auberge(10), 53)
        })
    })
    describe('Exercice CXII', () => {
        it('Retourne la famille dont le champs est plus grand d\'au moins 10m²', ()=> {
            assert.equal(scripts.champs(42, 54), 'La famille Evaran a un champs trop grand')
            assert.equal(scripts.champs(10, 20), '')
            assert.equal(scripts.champs(31, 20), 'La famille Arignon a un champs trop grand')
        })
    })
    describe('Exercice MCCXVI', () => {
        it('Retourne le nom de l\'arbre correspondant à ses caractéristiques', () => {
            assert.equal(scripts.arbres(12,12), 'Calaelen')
            assert.equal(scripts.arbres(4,9), 'Tinuviel')
            assert.equal(scripts.arbres(13, 6), 'Dorthonion')
            assert.equal(scripts.arbres(8, 3), 'Falarion')
        })
    })
    describe('Exercice XXII', () => {
        it('Retourne le prix de la chambre en fonction de l\'âge et du poids des bagages', () => {
            assert.equal(scripts.auberge2(22,25),40)
            assert.equal(scripts.auberge2(60, 33), 0)
            assert.equal(scripts.auberge2(3, 10),5)
            assert.equal(scripts.auberge2(25, 10), 30)
            assert.equal(scripts.auberge2(61, 30), 40)
            assert.equal(scripts.auberge2(71, 10), 30)
            assert.equal(scripts.auberge2(9, 20),5)
            assert.equal(scripts.auberge2(10, 20),40)
        })
    })
    describe('Exercice XXXII', () => {
        it('Retourne le nombre d\'amour de deux enfants', () => {
            assert.equal(scripts.loveNumber('ADA GWOAG'), '3 3')
            assert.equal(scripts.loveNumber('MICHEL BIDULE'), '8 2')
            assert.equal(scripts.loveNumber('XJDFS POEZAJFDSFGH'), '4 3')
            assert.equal(scripts.loveNumber('FJDSIFUEREOZPIF GFJGLFDJGDSQFJSD'), '7 6')
            assert.equal(scripts.loveNumber('FJDSIFUEREOZPIFREIEZRTUREIUTEHGJDFLGHDKFMDLFKSFS GFJGLFDJGDSQFJSDFJDSKFJKJDFSFJKDSJGUEIZRUPZEORZJFLKDSFS'), '5 2')
        })
    })
    describe('Exercice MCCXV', () => {
        it('Retourne un tableau des numéros des personnes en fonction de leur nouvelle position', () => {
            assert.deepEqual(scripts.positions(
                [5,3,1,2,3,4,5,1,2,1,3,4,0]
            ), [5,4,2,3,1])
            assert.deepEqual(scripts.positions(
                [8,4,7,2,3,4,1,5,6,8,0,2,3,4,5,6,1,7]
            ), [3,8,7,1,4,6,5,2])
        })
    })
    describe('Exercice 1984', () => {
        it('Retourne la hauteur de pyramide ainsi que le nombre de pierre nécessaire', () => {
            assert.equal(scripts.pyramide(20), '3 14')
            assert.equal(scripts.pyramide(26042), '42 25585')
        })
    })
    describe('Exercice 007', () => {
        it('Retourne les emplacements des jetons', () => {
            assert.deepEqual(
                scripts.espions([4,16,12,30,22,64,62,-5,86]),
                ['Dans une zone bleue', 'Dans une zone jaune', 'Dans une zone rouge', 'En dehors de la feuille']
            )
            assert.deepEqual(
                scripts.espions([10,10,-12,40,32,74,62,5,-86,90,30,26,30,52,10,20,54,70,90,0,0]),
                [
                    'En dehors de la feuille',
                    'Dans une zone jaune',
                    'Dans une zone rouge',
                    'En dehors de la feuille',
                    'Dans une zone jaune',
                    'Dans une zone jaune',
                    'Dans une zone bleue',
                    'Dans une zone bleue',
                    'En dehors de la feuille',
                    'Dans une zone jaune'
                ]
            )
        })
    })
    describe('Exercice 451', () => {
        it('Retourne un tableau de booléen pour chaque paire de rectange qui s\'intersectent', () => {
            assert.deepEqual(
                scripts.pompier([
                    [
                        [1,6,1,5],[4,9,3,8]
                    ]
                ]
                    ), [true]
            )
            assert.deepEqual(
                scripts.pompier([
                    [
                        [10,11,4,6],[9,12,3,5]
                    ]
                ]),[true]
            )
            assert.deepEqual(
                scripts.pompier([
                    [
                        [1,3,1,3],[3,5,3,5],
                    ],
                    [
                        [5,8,6,8],[2,6,7,10]
                    ]
                ]),
                [false,true]
            ),
            assert.deepEqual(
                scripts.pompier([
                    [
                        [8,10,1,2],[9,12,1,2]
                    ],
                    [
                        [8,10,9,11],[3,5,3,5]
                    ],
                    [
                        [11,13,7,9],[13,15,7,9]
                    ],
                    [
                        [5,8,1,3],[6,7,3,5]
                    ],
                    [
                        [2,6,7,10],[1,3,8,10]
                    ]
                ]),[true,false,false,false,true]
            )
        })
    })
    describe('Exercice CHESS', () => {
        it('Retourne un booléen si un cavalier blanc peut prendre une pièce adverse', () => {
            assert.equal(
                scripts.chess([
                    ['t','c','.','d','r','f','.','t'],
                    ['p','p','p','.','p','p','p','p'],
                    ['.','.','.','p','.','.','.','c'],
                    ['.','.','.','.','.','f','.','.'],
                    ['.','.','C','.','.','P','.','.'],
                    ['.','.','P','.','D','.','P','.'],
                    ['P','P','.','.','.','.','.','P'],
                    ['T','.','F','.','R','F','C','T']
                ]), true
            )
            assert.equal(
                scripts.chess([
                  ['t','.','.','d','r','f','.','t'],
                  ['p','p','.','c','.','p','p','p'],
                  ['.','.','p','.','.','c','.','.'],
                  ['.','.','.','.','p','.','.','.'],
                  ['.','.','.','.','p','.','f','.'],
                  ['.','.','.','P','.','C','P','.'],
                  ['P','P','P','C','.','P','F','P'],
                  ['T','.','F','D','.','T','R','.']
                ]),true
            )
            assert.equal(
                scripts.chess([
                    ['t','.','.','.','t','.','r','.'],
                    ['p','p','d','c','.','p','p','p'],
                    ['.','.','p','.','.','c','.','.'],
                    ['.','.','f','.','p','.','.','f'],
                    ['P','.','C','.','P','.','.','C'],
                    ['.','.','.','.','.','.','P','P'],
                    ['.','P','P','.','.','P','F','.'],
                    ['T','.','F','.','D','T','R','.']
                ]), true
            )
            assert.equal(
                scripts.chess([
                    ['.','d','.','t','c','f','r','.'],
                    ['.','.','.','c','.','p','p','.'],
                    ['.','.','p','.','t','.','p','.'],
                    ['.','p','.','.','p','.','.','.'],
                    ['.','.','.','.','P','.','P','.'],
                    ['.','.','D','.','F','.','.','P'],
                    ['T','P','P','.','.','P','F','.'],
                    ['.','.','.','T','.','.','R','.']
                    
                ]),false
            )
            assert.equal(
                scripts.chess([
                    ['.','d','.','.','.','f','r','.'],
                    ['.','.','.','T','.','p','p','.'],
                    ['.','.','p','c','t','.','p','.'],
                    ['.','.','.','.','p','.','.','.'],
                    ['.','.','p','.','P','.','P','.'],
                    ['.','.','D','.','F','.','.','P'],
                    ['.','P','P','.','.','P','F','.'],
                    ['.','.','.','.','.','.','R','.']
                ]), false
            )
            assert.equal(
                scripts.chess([
                    ['t','.','.','.','d','.','r','.'],
                    ['p','p','p','c','.','p','p','p'],
                    ['.','.','.','f','.','c','.','.'],
                    ['.','.','.','p','.','C','.','.'],
                    ['.','.','.','P','.','.','.','.'],
                    ['.','.','P','.','.','f','.','.'],
                    ['P','P','F','.','.','P','P','P'],
                    ['T','.','F','D','.','.','R','.']
                ]), true
            )
        })
    })
    describe('Exercice CAESAR', () => {
        it('Retourne un tableau des textes décryptés', () => {
            assert.deepEqual(
                scripts.cesar([
                    4,
                    'Ikio kyz rg ykiutjk vgmk ja robxk',
                    'Npeep alrp pde wl alrp yfxpcz 3',
                    'Qf hauou pazo xm cgmfduqyq bmsq !'
                ]),
                [
                    'Ceci est la seconde page du livre',
                    'Cette page est la page numero 3',
                    'Et voici donc la quatrieme page !'
                ]
            )
        })
    })
})