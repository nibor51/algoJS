module.exports = {

    /**
     * EXERCICE CXXIII
     * Détermine le prix à payer en fonction de l'heure d'arrivé
     * @param {Number} heure_arrive
     * @return {Number}
     */
    auberge: function(heure_arrive){
        // Algo pour l'exercice CXXIII
       

    },

    /**
     * EXERCICE CXII
     * Détermine le champs le plus grand d'au moins 10m²
     * @param {Number} superficie_arignon
     * @param {Number} superficie_evaran
     * @return {string}
     */
    champs: function(superficie_arignon, superficie_evaran){
        // Algo pour l'exercice CXII
       

    },


    /**
     * EXERCICE MCCXVI
     * Détermine le nom de l'arbre en fonction de ses caractéristiques
     * @param {Number} hauteur
     * @param {Number} nombre_folioles
     * @return {string}
     */
    arbres: function(hauteur, nombre_folioles){
        // Algo pour l'exercice MCCXVI
       

    },

    /**
     * EXERCICE XXII
     * Détermine le prix à payer
     * @param {Number} age
     * @param {Number} poids_bagage
     * @return {Number}
     */
    auberge2: function(age, poids_bagage){
        // Algo pour l'exercice XXII
        

    },


    /**
     * EXERCICE XXXII
     * Détermine le nombre d'amour de deux prénoms
     * @param {string} prenoms
     * @return {string}
     */
    loveNumber: function(prenoms){
        // Algo pour l'exercice XXXII
        

    },


    /**
     * EXERCICE MCCXV
     * Détermine la position des personnes après les changements
     * @param {array} input
     * @return {array}
     */
    positions: function(input){
        //Algo pour l'exercice MCCXV

        
    },


    /**
     * EXERCICE 1984
     * Détermine la hauteur et le nombre de pierres nécessaire à la construction d'une pyramide
     * @param {string} nombre_pierres
     * @return {string}
     */
    pyramide: function(nombre_pierres){
        // Algo pour l'exercice 1984
        

    },

    /**
     * EXERCICE 007
     * Test si des jetons se trouve dans une zone
     * @param {array} positions
     * @return {array}
     */
    espions: function(positions) {
        // Algo pour l'exercice 007
       

    },


    /**
     * EXERCICE 451
     * Test si les paires de rectanges s'intersectent
     * @param {array} input
     * @return {array}
     */
    pompier: function(input){
        // Algo pour l'exercice 451
       

    },

    /**
     * EXERCICE CHESS
     * Analyse un échiquier pour déterminer si un des cavaliers blanc peut prendre une pièce adverse 
     * @param {array} plateau 
     * @return {boolean}
     */
    chess: function(plateau){
      // Algo pour l'exercice des cavaliers 
      
    },


    /**
     * EXERCICE CAESAR
     * Décrypte un tableau de chaîne de chaîne de caractères
     * @param {array} input
     * @return {array}
     */
    cesar: function(input){
        // Algo pour l'exercice CAESAR

    },


}



/**
 * Test si un caractère est bien une lettre
 * @param {string} caractere
 * @returns {boolean}
 */

function isAlpha(caractere) {
    return /^[A-Z]$/i.test(caractere)
}

